Action()
{

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"none");

	web_custom_request("token", 
		"URL=https://www.googleapis.com/oauth2/v4/token", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t129.inf", 
		"Mode=HTML", 
		"Body=client_id=77185425430.apps.googleusercontent.com&client_secret=OTJgUOQcT7lO7GsGZq2G4IlT&grant_type=refresh_token&refresh_token=1//0ccq5gAMZaTPYCgYIARAAGAwSNwF-L9IrV2SZDs9XjjLUxbiC4bjcO21_gzi4_ktAFEZ4_dUQjfE6daehVwi1x6DeuyDL_f_astA&scope=https://www.googleapis.com/auth/chromesync", 
		LAST);

	web_add_cookie("HSID=AevVV72M7INcqD_T5; DOMAIN=accounts.google.com");

	web_add_cookie("SSID=A1Jwx5iMopahnWc0y; DOMAIN=accounts.google.com");

	web_add_cookie("APISID=Z0QUrZBmbAugwAkb/ANclSNCtoiID2npwc; DOMAIN=accounts.google.com");

	web_add_cookie("SAPISID=31fVRcD-hCP91jjV/ABaJgmQYMzy3JydKi; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PAPISID=31fVRcD-hCP91jjV/ABaJgmQYMzy3JydKi; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PAPISID=31fVRcD-hCP91jjV/ABaJgmQYMzy3JydKi; DOMAIN=accounts.google.com");

	web_add_cookie("SID=XAi5AZuH--rHf33ygEnxK9yjLBhcV6oNI6sVy8GgtqxE7drWGwsenHSpRH4oZcl2Hb3zMg.; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PSID=XAi5AZuH--rHf33ygEnxK9yjLBhcV6oNI6sVy8GgtqxE7drWgy4hKKROdjCfLFCOxYEIkw.; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSID=XAi5AZuH--rHf33ygEnxK9yjLBhcV6oNI6sVy8GgtqxE7drW79J4Wa4OijfHMCQmlN160w.; DOMAIN=accounts.google.com");

	web_add_cookie("SEARCH_SAMESITE=CgQIsZgB; DOMAIN=accounts.google.com");

	web_add_cookie("LSID=doritos|o.chat.google.com|o.drive.google.com|o.groups.google.com|o.lens.google.com|o.mail.google.com|s.RU|s.youtube:XAi5ATGebdM1gETRNM9R2g1x6TnupOcfVYwQ11kW0yg_Y9enC-G7tShdSlzdAmPmzI76ig.; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-1PLSID=doritos|o.chat.google.com|o.drive.google.com|o.groups.google.com|o.lens.google.com|o.mail.google.com|s.RU|s.youtube:XAi5ATGebdM1gETRNM9R2g1x6TnupOcfVYwQ11kW0yg_Y9enQkQlC7YwfM4ErnqyD4uUww.; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-3PLSID=doritos|o.chat.google.com|o.drive.google.com|o.groups.google.com|o.lens.google.com|o.mail.google.com|s.RU|s.youtube:XAi5ATGebdM1gETRNM9R2g1x6TnupOcfVYwQ11kW0yg_Y9en_fC4fRRkD8vNKHlWnO-2NA.; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-GAPS=1:IBdUgYSRO4i3-UGpHatoRwqNwAGqVqz18O13xLNgm_8HxRwB43kz0sigcySZkaAK1rrS0RpuoEDuh31QmZHoBVqSBny7dQ:csHqz2nZnGEJLBc9; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-ENID=12.SE=AsuaAtQirR8yzcvRhlzq2xlbFtCBF2x-vuTWvG3q2Ap7phVTHqqZWkofHgSz0gaGMvAW7svKolxc5HD-IX6sJlIppSnoQqiV6DGPbuVIM7y06VL9zRXGeEy1PcZQfCR2U2XCRQ42klmotG2__Hobo4QDA4TsvU-00NR1CkbblWLfZFcEkWnAIhJxE8OWcale0AE8MecMiVKPiYNT_eoBy919j6qSFkqLXytas2IkIENfcqAwz-1YpyA1Umx_gL1C; DOMAIN=accounts.google.com");

	web_add_cookie("AEC=AUEFqZcyrwyEXPoLYEHPZmV9SM_X_yEjm9fy80_yzYX198F2qAY2IQH0LQ; DOMAIN=accounts.google.com");

	web_add_cookie("NID=511=NSBfwWB6eBc5fjzWQ8AXY-X-_BnhcPWOYk695mVrohD_qtZRtXKKyyl7cMZlCr9ueWPPPBbgoXhz_zPJtSPPnItsZg4X6tdHzkLygZSGk7Npn_LDV11vRDSWYs6pGDw9Npny47oPbKMgeZgdDynKpbi5ehlfgVAdd8XkXeszzSUW7BKJvVjhlU5dbPMoN6aQio0IIDWeIYhJiHh2TS-8HleGD2QBHOjMnnTEoOIbUEAtNU4dq3WXzJ5rO7QyS5i_-gO8VQ1K5qFbnrGhtsAkrD2-T82RtQtusQ; DOMAIN=accounts.google.com");

	web_add_cookie("1P_JAR=2023-06-10-13; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PSIDTS=sidts-CjIBLFra0r4etGXMRQbihZgEkrXHiGvUSrL3n7o9X12yIln4gLfxR-Gk8nhzBAK45Sc6ExAA; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSIDTS=sidts-CjIBLFra0r4etGXMRQbihZgEkrXHiGvUSrL3n7o9X12yIln4gLfxR-Gk8nhzBAK45Sc6ExAA; DOMAIN=accounts.google.com");

	web_add_cookie("SIDCC=AP8dLtxyO5iOlxu-0q6_DFrXQYJNDwcPwb9ami9f4TJSrqnjxWw-vZxMmPmEjGxh3acPIu0YTzgS; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PSIDCC=AP8dLtxFxlBc9PvzxiuHDYIODmAa_6j3vJBtaBLc7qXACwb0OlMR6ShfaHDjKQcPHv1jyYyWItQ; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSIDCC=AP8dLtzLJdUc2u2IIDFIizbTQhwbx-yyQu-EmsNEEdI79vgkA03Bz2ECuw24P6CmRCpU0xXZf2sl; DOMAIN=accounts.google.com");

	web_add_header("Origin", 
		"https://www.google.com");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t130.inf", 
		"Mode=HTML", 
		"Body= ", 
		LAST);

	lr_start_transaction("openHomepage");

	web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"document");

	web_add_header("Purpose", 
		"prefetch");

	web_add_header("Sec-Fetch-User", 
		"?1");

	web_add_header("Sec-Purpose", 
		"prefetch;prerender");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_header("sec-ch-ua", 
		"\"Not.A/Brand\";v=\"8\", \"Chromium\";v=\"114\", \"Google Chrome\";v=\"114\"");

	web_add_header("sec-ch-ua-mobile", 
		"?0");

	web_add_header("sec-ch-ua-platform", 
		"\"Windows\"");

	lr_think_time(12);

	web_url("www.advantageonlineshopping.com", 
		"URL=https://www.advantageonlineshopping.com/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t131.inf", 
		"Mode=HTML", 
		LAST);

	return 0;
}